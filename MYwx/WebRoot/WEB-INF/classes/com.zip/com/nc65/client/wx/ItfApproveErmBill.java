/**
 * ItfApproveErmBill.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.nc65.client.wx;

public interface ItfApproveErmBill extends javax.xml.rpc.Service {
    public java.lang.String getItfApproveErmBillSOAP11port_httpAddress();

    public com.nc65.client.wx.ItfApproveErmBillPortType getItfApproveErmBillSOAP11port_http() throws javax.xml.rpc.ServiceException;

    public com.nc65.client.wx.ItfApproveErmBillPortType getItfApproveErmBillSOAP11port_http(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
